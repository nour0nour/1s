<?php
namespace Modules\Booking;
class Hook
{
    const BOOKING_SETTING_CONFIG = 'core_setting_config';
    const BOOKING_SETTING_AFTER_INVOICE = 'core_setting_after_invoice';
    const BOOKING_SETTING_AFTER_TERM = 'core_setting_after_term';
}
