<?php
namespace Modules\Core;
class Hook
{
    const CORE_SETTING_CONFIG = 'core_setting_config';
    const CORE_SETTING_AFTER_LOGO = 'core_setting_after_logo';
    const CORE_SETTING_AFTER_FOOTER = 'core_setting_after_footer';
    const CORE_SETTING_AFTER_CONTACT = 'core_setting_after_contact';
    const CORE_SETTING_AFTER_HOMEPAGE = 'core_setting_after_homepage';
    const MENU_ITEM_SETTING_MORE = 'menu_item_setting_more';
    const CORE_SETTING_ADD = 'core_setting_add';
    const STYLE_SETTING_AFTER_GENERAL_STYLE = 'CORE_SETTING_AFTER_GENERAL_STYLE';

    const AFTER_SETTING_SAVED = 'AFTER_SETTING_SAVED';
}
