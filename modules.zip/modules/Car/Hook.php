<?php
namespace Modules\Car;
class Hook
{
    const FORM_AFTER_SERVICE_FEE = 'car_form_after_service_fee';
    const AFTER_SAVING = 'car_after_saving';


    const CAR_SETTING_CONFIG = 'car_setting_config';
    const CAR_SETTING_AFTER_MAP = 'car_setting_after_map';

    const CAR_SETTING_AFTER_LAYOUT_SEARCH = 'car_setting_layout_detail';

}
