<?php
return [
    'admin_route_prefix' => env("ADMIN_ROUTER_PREFIX","admin"),
];
